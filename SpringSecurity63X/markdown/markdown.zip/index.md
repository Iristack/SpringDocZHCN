Spring Security 提供了与
{spring-framework-reference-url}testing/mockmvc.html\[Spring MVC Test\]
的全面集成。
