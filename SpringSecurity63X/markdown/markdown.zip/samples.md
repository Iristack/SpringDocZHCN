Spring Security 包含了许多 {gh-samples-url}\[示例\] 应用程序。

:::: note
::: title
:::

这些示例正在迁移到一个单独的项目中，但你仍然可以在
{gh-old-samples-url}\[Spring Security 仓库\]
的较旧分支中找到尚未迁移的示例。
::::
