`AbstractSecurityInterceptor` 能够在安全对象回调阶段临时替换
`SecurityContext` 和 `SecurityContextHolder` 中的 `Authentication`
对象。 这种情况仅在原始的 `Authentication` 对象已成功通过
`AuthenticationManager` 和 `AccessDecisionManager` 处理后才会发生。
`RunAsManager` 会指明在 `SecurityInterceptorCallback` 阶段应使用的替代
`Authentication` 对象（如果有的话）。

通过在安全对象回调阶段临时替换 `Authentication`
对象，受保护的方法调用可以访问其他需要不同身份认证和授权凭证的对象。
它还可以对特定的 `GrantedAuthority` 对象执行任何内部安全检查。 由于
Spring Security 提供了多个辅助类，这些类会根据 `SecurityContextHolder`
的内容自动配置远程调用协议，因此这种 run-as 替换在调用远程 Web
服务时特别有用。

# 配置 {#runas-config}

Spring Security 提供了一个 `RunAsManager` 接口：

``` java
Authentication buildRunAs(Authentication authentication, Object object,
    List<ConfigAttribute> config);

boolean supports(ConfigAttribute attribute);

boolean supports(Class clazz);
```

第一个方法返回一个 `Authentication` 对象，在方法调用期间将用来替换当前的
`Authentication` 对象。 如果该方法返回 `null`，则表示不应进行替换。
第二个方法由 `AbstractSecurityInterceptor` 在启动时用于验证配置属性。
`supports(Class)` 方法由安全拦截器实现调用，以确保所配置的
`RunAsManager` 支持该安全拦截器所处理的安全对象类型。

Spring Security 提供了一个具体的 `RunAsManager` 实现：
`RunAsManagerImpl` 类会在任意 `ConfigAttribute` 以 `RUN_AS_`
开头时返回一个替代的 `RunAsUserToken`。 如果发现此类
`ConfigAttribute`，则生成的 `RunAsUserToken` 将包含与原始
`Authentication`
对象相同的主体（principal）、凭据（credentials）和授予的权限（granted
authorities），并为每个 `RUN_AS_` 类型的 `ConfigAttribute` 添加一个新的
`SimpleGrantedAuthority`。 每个新的 `SimpleGrantedAuthority` 以前缀
`ROLE_` 开头，后接该 `RUN_AS_` 的
`ConfigAttribute`。例如，`RUN_AS_SERVER` 将导致替换后的 `RunAsUserToken`
包含一个名为 `ROLE_RUN_AS_SERVER` 的授权。

这个替换用的 `RunAsUserToken` 与其他 `Authentication` 对象一样，需要由
`AuthenticationManager` 进行认证，通常通过委托给合适的
`AuthenticationProvider` 来完成。 `RunAsImplAuthenticationProvider`
就是用于执行此类认证的实现类，它可以接受任何有效的 `RunAsUserToken`。

为了防止恶意代码创建 `RunAsUserToken`
并提交以获得无条件接受，所有生成的令牌中都存储了一个密钥的哈希值。
`RunAsManagerImpl` 和 `RunAsImplAuthenticationProvider` 在 Bean
上下文中使用相同的密钥创建：

``` xml
<bean id="runAsManager"
    class="org.springframework.security.access.intercept.RunAsManagerImpl">
<property name="key" value="my_run_as_password"/>
</bean>

<bean id="runAsAuthenticationProvider"
    class="org.springframework.security.access.intercept.RunAsImplAuthenticationProvider">
<property name="key" value="my_run_as_password"/>
</bean>
```

通过使用相同的密钥，可验证每一个 `RunAsUserToken` 是否由受信任的
`RunAsManagerImpl` 所创建。 出于安全考虑，`RunAsUserToken`
在创建后是不可变的。
