Spring Security 提供了以下内置机制，用于从 `HttpServletRequest`
中读取用户名和密码：
