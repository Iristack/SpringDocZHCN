{security-api-url}org/springframework/security/core/CredentialsContainer.html\[`CredentialsContainer`\]
接口表明其实现对象包含敏感数据，并由 Spring Security
在内部使用，用于在成功认证后清除认证凭据。 该接口被 Spring Security
大多数内部领域类所实现，例如
{security-api-url}org/springframework/security/core/userdetails/User.html\[User\]
和
{security-api-url}org/springframework/security/authentication/UsernamePasswordAuthenticationToken.html\[UsernamePasswordAuthenticationToken\]。

`ProviderManager` 会检查返回的 `Authentication`
是否实现了此接口。如果是，则 [调用其 `eraseCredentials`
方法](servlet/authentication/architecture.xml#servlet-authentication-providermanager-erasing-credentials)，以从对象中移除凭据。

如果你希望自定义的认证对象在认证完成后清除其凭据，则应确保相关类实现
`CredentialsContainer` 接口。

编写自己 `AuthenticationProvider`
实现的开发者，应在其中创建并返回一个合适的 `Authentication`
对象，并直接排除任何敏感数据，而不是依赖此接口来清除凭据。
